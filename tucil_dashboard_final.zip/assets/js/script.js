
Chart.register(ChartDataLabels);
let rawData = [];
let pnrmChoices;
let unitChoices;
let unitSelect = document.getElementById('unit');
let isAscending = true;

document.addEventListener('DOMContentLoaded', () => {
  pnrmChoices = new Choices('#pnrm', {
    searchEnabled: true,
    itemSelectText: '',
    shouldSort: false,
    placeholder: true,
    searchPlaceholderValue: 'Ketik nama PN...'
  });
  unitChoices = new Choices('#unit', {
    searchEnabled: true,
    itemSelectText: '',
    shouldSort: false,
    placeholder: true
  });

  document.getElementById('toggleSortBtn').addEventListener('click', () => {
    isAscending = !isAscending;
    document.getElementById('toggleSortBtn').textContent =
      `Urutkan TOTAL TUNGGAKAN (${isAscending ? 'Naik' : 'Turun'})`;
    updateDashboard();
  });

  document.getElementById('excelFile').addEventListener('change', function (e) {
    const file = e.target.files[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = function (evt) {
      const data = new Uint8Array(evt.target.result);
      const workbook = XLSX.read(data, { type: "array" });
      const sheetName = workbook.SheetNames[0];
      const sheet = workbook.Sheets[sheetName];
      rawData = XLSX.utils.sheet_to_json(sheet);
      updateCabangSelector();
      updateUnitSelector();
      updatePnrmSelector();
      updateDashboard();
    };
    reader.readAsArrayBuffer(file);
  });

  document.getElementById('pnrm').addEventListener('change', updateDashboard);
  document.getElementById('cabang').addEventListener('change', () => {
    updateUnitSelector();
    updatePnrmSelector();
    updateDashboard();
  });
  document.getElementById('unit').addEventListener('change', () => {
    updatePnrmSelector();
    updateDashboard();
  });
});

function updateCabangSelector() {
  const cabangSet = new Set(rawData.map(r => r['MBDESC']));
  const cabangSelect = document.getElementById('cabang');
  cabangSelect.innerHTML = '<option value="all">Semua</option>';
  cabangSet.forEach(c => cabangSelect.innerHTML += `<option value="${c}">${c}</option>`);
}

function updateUnitSelector() {
  const cabangFilter = document.getElementById('cabang').value;
  const unitSet = new Set(
    rawData.filter(r => cabangFilter === 'all' || r['MBDESC'] === cabangFilter)
           .map(r => r['BRDESC'])
  );
  unitChoices.clearStore();
  unitChoices.setChoices([
    { value: 'all', label: 'Semua', selected: true },
    ...[...unitSet].map(u => ({ value: u, label: u }))
  ], 'value', 'label', true);
}

function updatePnrmSelector() {
  const cabangFilter = document.getElementById('cabang').value;
  const unitFilter = unitSelect.value;
  const pnrmSet = new Set(
    rawData.filter(r =>
      (cabangFilter === 'all' || r['MBDESC'] === cabangFilter) &&
      (unitFilter === 'all' || r['BRDESC'] === unitFilter)
    ).map(r => r['PN_RM_Pengelola_1'])
  );
  pnrmChoices.clearStore();
  pnrmChoices.setChoices([
    { value: 'all', label: 'Semua', selected: true },
    ...[...pnrmSet].map(p => ({ value: p, label: p }))
  ], 'value', 'label', true);
}

function updateDashboard() {
  const pnrmFilter = document.getElementById('pnrm').value;
  const cabangFilter = document.getElementById('cabang').value;
  const unitFilter = unitSelect.value;

  let filtered = rawData.filter(row =>
    (pnrmFilter === 'all' || row['PN_RM_Pengelola_1'] === pnrmFilter) &&
    (cabangFilter === 'all' || row['MBDESC'] === cabangFilter) &&
    (unitFilter === 'all' || row['BRDESC'] === unitFilter)
  );

  filtered.sort((a, b) => {
    const aVal = parseFloat((a['TOTAL TUNGGAKAN'] || '0').toString().replace(/\./g, '').replace(/,/g, '.')) || 0;
    const bVal = parseFloat((b['TOTAL TUNGGAKAN'] || '0').toString().replace(/\./g, '').replace(/,/g, '.')) || 0;
    return isAscending ? aVal - bVal : bVal - aVal;
  });

  const tbody = document.querySelector('#rekeningTable tbody');
  tbody.innerHTML = '';

  filtered.forEach(row => {
    const osRaw = row['OS'] ?? 0;
    const tunggakanRaw = row['TOTAL TUNGGAKAN'] ?? 0;

    const os = typeof osRaw === 'string'
      ? parseFloat(osRaw.replace(/\./g, '').replace(/,/g, '.')) || 0
      : parseFloat(osRaw) || 0;

    const tunggakan = typeof tunggakanRaw === 'string'
      ? parseFloat(tunggakanRaw.replace(/\./g, '').replace(/,/g, '.')) || 0
      : parseFloat(tunggakanRaw) || 0;

    const tr = document.createElement('tr');
    tr.innerHTML = `
      <td>${row['Textbox190'] || ''}</td>
      <td>${row['SNAME'] || ''}</td>
      <td>${os.toLocaleString('id-ID')}</td>
      <td>${tunggakan.toLocaleString('id-ID')}</td>
      <td>${row['PN_RM_Pengelola_1'] || ''}</td>
      <td>${row['MBDESC'] || ''}</td>
      <td>${row['BRDESC'] || ''}</td>
    `;
    tbody.appendChild(tr);
  });
}
